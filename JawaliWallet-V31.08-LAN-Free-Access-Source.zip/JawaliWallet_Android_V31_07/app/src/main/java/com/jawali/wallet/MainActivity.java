package com.jawali.wallet;

import android.app.Activity;
import android.app.Dialog;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.content.Intent;
import android.view.View;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.os.Build;
import android.hardware.biometrics.BiometricPrompt;
import android.os.CancellationSignal;
import android.content.DialogInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
  private WebView web;
  private final ExecutorService apiExecutor = Executors.newFixedThreadPool(3);
  private String stableDeviceToken() {
    SharedPreferences prefs=getSharedPreferences("jawali_secure_install",Context.MODE_PRIVATE);
    String token=prefs.getString("device_token",null);
    if (token==null || token.length()<16) {
      byte[] random=new byte[32]; new SecureRandom().nextBytes(random);
      StringBuilder b=new StringBuilder(); for(byte v:random)b.append(String.format(java.util.Locale.ROOT,"%02x",v&0xff));
      token=b.toString(); prefs.edit().putString("device_token",token).apply();
    }
    return token;
  }
  private void sendApiResult(int id,int status,String payload) {
    final String js="window.JawaliLive&&window.JawaliLive.receive("+id+","+status+","+JSONObject.quote(payload)+")";
    runOnUiThread(()->{ if(web!=null)web.evaluateJavascript(js,null); });
  }
  private static String readResponse(InputStream input) throws Exception {
    if(input==null)return "";
    try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){
      byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>2097152)throw new Exception("استجابة الخادم كبيرة جدًا");}
      return out.toString("UTF-8");
    }
  }

  public class JawaliBridge {
    @JavascriptInterface public String deviceToken() {return stableDeviceToken();}
    @JavascriptInterface public void apiRequest(int id,String urlText,String method,String jwt,String jsonBody) {
      apiExecutor.execute(()->{
        HttpURLConnection connection=null;
        try {
          URL url=new URL(urlText);
          if(!"https".equalsIgnoreCase(url.getProtocol())) throw new Exception("يلزم اتصال HTTPS موثوق بالخادم");
          if(!"alfaisal.taild58c1c.ts.net".equalsIgnoreCase(url.getHost()) || url.getPort()!=-1 || url.getUserInfo()!=null) throw new Exception("عنوان خادم غير معتمد");
          if(!url.getPath().startsWith("/api/"))throw new Exception("مسار API غير صالح");
          if(!"GET".equals(method) && !"POST".equals(method))throw new Exception("نوع الطلب غير مدعوم");
          connection=(HttpURLConnection)url.openConnection();
          connection.setConnectTimeout(30000);
          connection.setReadTimeout("/api/client/wifi-phone-login".equals(url.getPath())?95000:30000);
          connection.setInstanceFollowRedirects(false);connection.setRequestMethod(method);
          connection.setRequestProperty("Accept","application/json");
          if(jwt!=null && !jwt.isEmpty())connection.setRequestProperty("Authorization","Bearer "+jwt);
          if("POST".equals(method)){
            connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json; charset=UTF-8");
            byte[] bytes=jsonBody.getBytes(StandardCharsets.UTF_8);
            if(bytes.length>16384)throw new Exception("حجم الطلب غير صالح");
            try(java.io.OutputStream o=connection.getOutputStream()){o.write(bytes);}
          }
          int status=connection.getResponseCode();
          if(status>=300 && status<400)throw new Exception("إعادة توجيه API غير مسموحة");
          sendApiResult(id,status,readResponse(status>=400?connection.getErrorStream():connection.getInputStream()));
        }catch(java.net.SocketTimeoutException e){
          sendApiResult(id,0,"{\"message\":"+JSONObject.quote("انتهت مهلة الاتصال بخادم المحفظة. افحص حالة الباقة والعمليات قبل إعادة التفعيل.")+"}");
        }catch(java.net.ConnectException e){
          sendApiResult(id,0,"{\"message\":"+JSONObject.quote("تعذر الاتصال بخادم المحفظة. تأكد من اتصال Tailscale ثم جرّب فحص الخادم.")+"}");
        }catch(Exception e){sendApiResult(id,0,"{\"message\":"+JSONObject.quote(e.getMessage()==null?"فشل الاتصال":e.getMessage())+"}");}
        finally{if(connection!=null)connection.disconnect();}
      });
    }

    @JavascriptInterface public void openHotspotLogin(String loginUrl,String username,String password){
      runOnUiThread(()->showHotspotLogin(loginUrl,username,password));
    }

    @JavascriptInterface public void requestBiometric() {
      runOnUiThread(() -> {
        if (Build.VERSION.SDK_INT < 28) { Toast.makeText(MainActivity.this,"البصمة غير مدعومة على هذا الإصدار",Toast.LENGTH_LONG).show(); return; }
        try {
          BiometricPrompt prompt = new BiometricPrompt.Builder(MainActivity.this)
            .setTitle("التحقق ببصمة الجهاز")
            .setSubtitle("جوالي محفظتي — معاينة محلية")
            .setNegativeButton("إلغاء", getMainExecutor(), (dialog, which) -> biometricResult(false))
            .build();
          prompt.authenticate(new CancellationSignal(),getMainExecutor(),new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) { biometricResult(true); }
            @Override public void onAuthenticationError(int code,CharSequence message) { biometricResult(false); }
          });
        } catch(Exception e) { Toast.makeText(MainActivity.this,"تأكد من تسجيل بصمة في إعدادات الهاتف",Toast.LENGTH_LONG).show(); }
      });
    }
  }
  private void showHotspotLogin(String urlText,String username,String password){
    try{
      Uri uri=Uri.parse(urlText);
      if(!"http".equalsIgnoreCase(uri.getScheme()) || !"172.16.0.1".equals(uri.getHost())
          || (uri.getPort()!=-1 && uri.getPort()!=80)
          || !"/login".equals(uri.getPath()) || uri.getUserInfo()!=null){
        Toast.makeText(this,"عنوان Hotspot غير معتمد",Toast.LENGTH_LONG).show();return;
      }
      
      WebView hotspot=new WebView(this);
      hotspot.getSettings().setJavaScriptEnabled(true);
      hotspot.getSettings().setDomStorageEnabled(true);
      hotspot.getSettings().setAllowFileAccess(false);
      hotspot.getSettings().setAllowContentAccess(false);
      hotspot.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
      final boolean[] attempted={false};
      final boolean[] authenticated={false};
      final boolean[] pageFinished={false};
      final String[] currentPage={"لم يبدأ تحميل الصفحة"};
      final android.widget.FrameLayout parent=(android.widget.FrameLayout)web.getParent();
      final String jsUsername=JSONObject.quote(username);
      final String jsPassword=JSONObject.quote(password);
      java.util.function.BiConsumer<String,String> feedback=(state,message)->{
        final String script="window.jawaliHotspotState&&window.jawaliHotspotState("+JSONObject.quote(state)+","+JSONObject.quote(message)+")";
        web.evaluateJavascript(script,null);
      };
      hotspot.setWebViewClient(new WebViewClient(){
        @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
          Uri target=request.getUrl();
          String host=target.getHost();
          boolean trusted="172.16.0.1".equalsIgnoreCase(host)||"a.com".equalsIgnoreCase(host);
          if(!trusted)feedback.accept("failed","تحويل الدخول إلى نطاق غير معتمد: "+String.valueOf(host));
          return !("http".equalsIgnoreCase(target.getScheme())&&trusted
            && (target.getPort()==-1||target.getPort()==80));
        }
        @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap favicon){
          currentPage[0]=Uri.parse(url).getPath();
          Uri location=Uri.parse(url);
          String host=location.getHost();
          if("172.16.0.1".equalsIgnoreCase(host)||"a.com".equalsIgnoreCase(host))
            feedback.accept("pending","جارٍ التواصل مع بوابة الشبكة: "+String.valueOf(location.getPath()));
        }
        @Override public void onReceivedHttpError(WebView view,WebResourceRequest request,android.webkit.WebResourceResponse response){
          if(request.isForMainFrame())feedback.accept("failed","أرجع الراوتر HTTP "+response.getStatusCode()+" أثناء تسجيل الدخول");
        }
        @Override public void onPageFinished(WebView view,String url){
          pageFinished[0]=true;
          currentPage[0]=Uri.parse(url).getPath();
          Uri current=Uri.parse(url);
          boolean portal="172.16.0.1".equalsIgnoreCase(current.getHost())||"a.com".equalsIgnoreCase(current.getHost());
          if(portal&&"/status".equals(current.getPath())){
            // Check the response itself before showing "connected" in the wallet.
            view.evaluateJavascript("(function(){return !!(document.querySelector('a[href*=logout],form[action*=logout]')||document.body.textContent.includes('session-time-left'));})()",
              result->{
                if("true".equals(result)){
                  authenticated[0]=true;
                  feedback.accept("connected","تم تسجيل دخول الهاتف؛ صفحة استهلاك المحفظة جاهزة");
                }else feedback.accept("failed","لم يؤكد الراوتر جلسة نشطة؛ راجع سبب رفض الدخول في السجلات");
              });
            return;
          }
          if(!portal||attempted[0]||authenticated[0])return;
          // Different captive templates serve the login form at different paths.
          // Find a real username field before deciding that this is a login page.
          view.evaluateJavascript("(function(){return JSON.stringify({path:location.pathname,forms:document.forms.length,username:!!document.querySelector('input[name=username]'),title:document.title})})()",probe->{
            if(probe!=null)feedback.accept("pending","تم تحميل البوابة: "+String.valueOf(current.getPath()));
          });
          if(!("/login".equals(current.getPath())||"/".equals(current.getPath())||"/login.html".equals(current.getPath())))return;
          attempted[0]=true;
          feedback.accept("pending","تم الوصول إلى الراوتر؛ جارٍ إرسال بيانات الهاتف");
          // Submit the actual form. requestSubmit/click triggers the router's own
          // onsubmit handler (including CHAP if configured), unlike form.submit().
          String script="(function(){try{"+
            "var u=document.querySelector('input[name=username]');"+
            "var p=document.querySelector('input[name=password]');"+
            "if(!u)return 'FORM_NOT_FOUND';"+
            "u.value="+jsUsername+";"+
            "u.dispatchEvent(new Event('input',{bubbles:true}));"+
            "if(p){p.value="+jsPassword+";p.dispatchEvent(new Event('input',{bubbles:true}));}"+
            "var f=u.form||document.querySelector('form[name=login],form[action*=login]');"+
            "if(!f)return 'FORM_NOT_FOUND';"+
            "var btn=f.querySelector('button[type=submit],input[type=submit]');"+
            "if(btn){btn.click();return 'LOGIN_SUBMITTED'}"+
            "if(typeof f.requestSubmit==='function'){f.requestSubmit();return 'LOGIN_SUBMITTED'}"+
            "if(typeof window.doLogin==='function'){window.doLogin();return 'CHAP_SUBMITTED'}"+
            "return 'SUBMIT_HANDLER_NOT_FOUND'"+
            "}catch(e){return 'FORM_ERROR:'+String(e.message||e)}})()";
          view.evaluateJavascript(script,result->{
            String code=result==null?"NULL":result.replace("\"","");
            if(code.startsWith("LOGIN_SUBMITTED")||code.startsWith("CHAP_SUBMITTED")){
              feedback.accept("pending","أُرسلت بيانات الدخول؛ جارٍ التحقق من الجلسة");
              // Read status only if login response did not already navigate there.
              view.postDelayed(()->{
                if(!authenticated[0]&&view.getUrl()!=null&&view.getUrl().contains("/login")){
                  view.loadUrl("http://172.16.0.1/status");
                }
              },7500);
            } else {
              feedback.accept("failed","تعذر إرسال نموذج الدخول ("+code+") في "+String.valueOf(currentPage[0]));
            }
          });
        }
        @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){
          if(request.isForMainFrame())feedback.accept("failed","تعذر فتح بوابة الشبكة: "+String.valueOf(error.getDescription())+" (رمز "+error.getErrorCode()+")");
        }
      });
      hotspot.setAlpha(0f);
      hotspot.setFocusable(false);
      parent.addView(hotspot,0,new android.widget.FrameLayout.LayoutParams(
        android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
        android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
      hotspot.postDelayed(()->{
        if(!authenticated[0]&&!attempted[0]){
          if(!pageFinished[0]){
            feedback.accept("failed","لم يكتمل تحميل بوابة الراوتر من الهاتف. تحقق من Wi-Fi وأوقف VPN مؤقتًا. المسار: "+currentPage[0]);
          } else {
            feedback.accept("failed","فتحت البوابة ولكن لم يظهر نموذج الدخول في المسار: "+currentPage[0]+". قد تكون صفحة إعادة توجيه أو جلسة أخرى");
          }
        }
      },15000);
      hotspot.loadUrl("http://172.16.0.1/login");
    }catch(Exception e){Toast.makeText(this,"تعذر فتح صفحة الدخول: "+e.getMessage(),Toast.LENGTH_LONG).show();}
  }
  private void biometricResult(boolean ok) {
    web.evaluateJavascript("if(typeof jawaliBiometricResult==='function')jawaliBiometricResult("+ok+")",null);
  }
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(18,31,49));
    web = new WebView(this);
    setContentView(web);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.getSettings().setAllowFileAccessFromFileURLs(false);
    web.getSettings().setAllowUniversalAccessFromFileURLs(false);
    web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.addJavascriptInterface(new JawaliBridge(), "JawaliNative");
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        Uri uri=request.getUrl();
        if ("file".equals(uri.getScheme()) && "android_asset".equals(uri.getHost())) return false;
        if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
          startActivity(new Intent(Intent.ACTION_VIEW,uri)); return true;
        }
        return true;
      }
    });
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed() {
    if (web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
  @Override protected void onDestroy() {
    apiExecutor.shutdownNow(); web.destroy(); super.onDestroy();
  }
}
