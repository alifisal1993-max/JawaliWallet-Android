package com.jawali.wallet;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.content.Intent;
import android.view.View;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.os.Build;
import android.hardware.biometrics.BiometricPrompt;
import android.os.CancellationSignal;
import android.content.DialogInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
  private WebView web;
  private final ExecutorService apiExecutor = Executors.newSingleThreadExecutor();
  private String stableDeviceToken() {
    SharedPreferences prefs=getSharedPreferences("jawali_secure_install",Context.MODE_PRIVATE);
    String token=prefs.getString("device_token",null);
    if (token==null || token.length()<16) {
      byte[] random=new byte[32]; new SecureRandom().nextBytes(random);
      StringBuilder b=new StringBuilder(); for(byte v:random)b.append(String.format(java.util.Locale.ROOT,"%02x",v&0xff));
      token=b.toString(); prefs.edit().putString("device_token",token).apply();
    }
    return token;
  }
  private void sendApiResult(int id,int status,String payload) {
    final String js="window.JawaliLive&&window.JawaliLive.receive("+id+","+status+","+JSONObject.quote(payload)+")";
    runOnUiThread(()->{ if(web!=null)web.evaluateJavascript(js,null); });
  }
  private static String readResponse(InputStream input) throws Exception {
    if(input==null)return "";
    try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){
      byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>2097152)throw new Exception("استجابة الخادم كبيرة جدًا");}
      return out.toString("UTF-8");
    }
  }

  public class JawaliBridge {
    @JavascriptInterface public String deviceToken() {return stableDeviceToken();}
    @JavascriptInterface public void apiRequest(int id,String urlText,String method,String jwt,String jsonBody) {
      apiExecutor.execute(()->{
        HttpURLConnection connection=null;
        try {
          URL url=new URL(urlText);
          if(!"https".equalsIgnoreCase(url.getProtocol())) throw new Exception("يلزم اتصال HTTPS موثوق بالخادم");
          if(!"alfaisal.taild58c1c.ts.net".equalsIgnoreCase(url.getHost()) || url.getPort()!=-1 || url.getUserInfo()!=null) throw new Exception("عنوان خادم غير معتمد");
          if(!url.getPath().startsWith("/api/"))throw new Exception("مسار API غير صالح");
          if(!"GET".equals(method) && !"POST".equals(method))throw new Exception("نوع الطلب غير مدعوم");
          connection=(HttpURLConnection)url.openConnection();
          connection.setConnectTimeout(12000);connection.setReadTimeout(15000);
          connection.setInstanceFollowRedirects(false);connection.setRequestMethod(method);
          connection.setRequestProperty("Accept","application/json");
          if(jwt!=null && !jwt.isEmpty())connection.setRequestProperty("Authorization","Bearer "+jwt);
          if("POST".equals(method)){
            connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json; charset=UTF-8");
            byte[] bytes=jsonBody.getBytes(StandardCharsets.UTF_8);
            if(bytes.length>16384)throw new Exception("حجم الطلب غير صالح");
            try(java.io.OutputStream o=connection.getOutputStream()){o.write(bytes);}
          }
          int status=connection.getResponseCode();
          if(status>=300 && status<400)throw new Exception("إعادة توجيه API غير مسموحة");
          sendApiResult(id,status,readResponse(status>=400?connection.getErrorStream():connection.getInputStream()));
        }catch(Exception e){sendApiResult(id,0,"{\"message\":"+JSONObject.quote(e.getMessage()==null?"فشل الاتصال":e.getMessage())+"}");}
        finally{if(connection!=null)connection.disconnect();}
      });
    }

    @JavascriptInterface public void requestBiometric() {
      runOnUiThread(() -> {
        if (Build.VERSION.SDK_INT < 28) { Toast.makeText(MainActivity.this,"البصمة غير مدعومة على هذا الإصدار",Toast.LENGTH_LONG).show(); return; }
        try {
          BiometricPrompt prompt = new BiometricPrompt.Builder(MainActivity.this)
            .setTitle("التحقق ببصمة الجهاز")
            .setSubtitle("جوالي محفظتي — معاينة محلية")
            .setNegativeButton("إلغاء", getMainExecutor(), (dialog, which) -> biometricResult(false))
            .build();
          prompt.authenticate(new CancellationSignal(),getMainExecutor(),new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) { biometricResult(true); }
            @Override public void onAuthenticationError(int code,CharSequence message) { biometricResult(false); }
          });
        } catch(Exception e) { Toast.makeText(MainActivity.this,"تأكد من تسجيل بصمة في إعدادات الهاتف",Toast.LENGTH_LONG).show(); }
      });
    }
  }
  private void biometricResult(boolean ok) {
    web.evaluateJavascript("if(typeof jawaliBiometricResult==='function')jawaliBiometricResult("+ok+")",null);
  }
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(Color.rgb(18,31,49));
    web = new WebView(this);
    setContentView(web);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.getSettings().setAllowFileAccessFromFileURLs(false);
    web.getSettings().setAllowUniversalAccessFromFileURLs(false);
    web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.addJavascriptInterface(new JawaliBridge(), "JawaliNative");
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        Uri uri=request.getUrl();
        if ("file".equals(uri.getScheme()) && "android_asset".equals(uri.getHost())) return false;
        if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
          startActivity(new Intent(Intent.ACTION_VIEW,uri)); return true;
        }
        return true;
      }
    });
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed() {
    if (web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
  @Override protected void onDestroy() {
    apiExecutor.shutdownNow(); web.destroy(); super.onDestroy();
  }
}
