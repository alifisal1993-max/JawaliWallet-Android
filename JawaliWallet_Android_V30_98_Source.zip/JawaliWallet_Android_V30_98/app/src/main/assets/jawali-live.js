/* Jawali Wallet V30.92 - actual server-backed client services.
 * This app deliberately requires trusted HTTPS and does not simulate financial operations.
 * The server is authoritative. No financial write is automatically retried.
 */
(function(){
'use strict';
let liveUser=null, token=null, apiBase='https://alfaisal.taild58c1c.ts.net', liveData={}, reqId=0;
const inflight=new Map(); let busy=false;
const SERVER_URL='https://alfaisal.taild58c1c.ts.net';
const saved=SERVER_URL;
function errorText(error){return error?.message||'حدث خطأ أثناء الاتصال بالخادم'}
function baseUrl(v){let u;try{u=new URL(String(v).trim())}catch(e){throw new Error('أدخل عنوان HTTPS صالحًا')}
 if(u.origin!==SERVER_URL||u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.pathname!=='/')throw new Error('هذا التطبيق مخصص لخادم جوالي محفظتي المعتمد فقط');return SERVER_URL;}
function call(path,method='GET',body){
 if(!window.JawaliNative?.apiRequest)return Promise.reject(new Error('التطبيق يحتاج إلى جسر Android للاتصال'));
 if(!apiBase)return Promise.reject(new Error('لم يُحدد عنوان الخادم'));
 return new Promise((resolve,reject)=>{const id=++reqId;const timeout=setTimeout(()=>{inflight.delete(id);reject(new Error('انتهت مهلة الاتصال بالخادم؛ تحقق من سجل العمليات قبل إعادة أي دفع'))},25000);
 inflight.set(id,{resolve,reject,timeout});try{JawaliNative.apiRequest(id,apiBase+path,method,token||'',body===undefined?'':JSON.stringify(body));}catch(e){clearTimeout(timeout);inflight.delete(id);reject(e)}})
}
window.JawaliLive={receive(id,status,payload){const p=inflight.get(id);if(!p)return;inflight.delete(id);clearTimeout(p.timeout);let obj;try{obj=JSON.parse(payload||'{}')}catch(e){return p.reject(new Error('رد غير صالح من الخادم'))}if(status<200||status>=300){const e=new Error(obj.message||'تعذر تنفيذ الطلب ('+status+')');e.code=obj.code;e.status=status;return p.reject(e)}p.resolve(obj)}};
const fmt=n=>Number.isFinite(Number(n))?Number(n).toLocaleString('ar-YE',{maximumFractionDigits:2}):'—';const rial=n=>fmt(n)+' ر.ي';
const safe=v=>esc(String(v===null||v===undefined?'':v));
function notice(t){return `<p class="lv-note">${safe(t)}</p>`}
function panel(title,content){return `<section class="lv-panel"><h3>${safe(title)}</h3>${content}</section>`}
function line(title,value){return `<div class="lv-line"><span>${safe(title)}</span><b>${safe(value)}</b></div>`}
function button(title,fn,extra=''){return `<button class="lv-action" ${extra} onclick="${fn}">${safe(title)}</button>`}
function card(title,desc,amount,buttonText,action){return `<article class="lv-card"><b>${safe(title)}</b><small>${safe(desc)}</small><strong>${safe(amount)}</strong>${buttonText?button(buttonText,action):''}</article>`}
function status(t){const el=document.getElementById('live-status');if(el)el.textContent=t;else toast(t)}
async function refresh(){const entries=[['wallet','/api/client/wallet'],['packages','/api/client/packages'],['profiles','/api/client/phone-profiles'],['water','/api/client/water'],['cards','/api/client/cards'],['requests','/api/client/requests']];const rs=await Promise.allSettled(entries.map(e=>call(e[1])));const faults=[];
 rs.forEach((r,i)=>{if(r.status==='fulfilled')liveData[entries[i][0]]=r.value;else faults.push(entries[i][0]+': '+errorText(r.reason))});if(!liveData.wallet)throw new Error('تعذّر جلب المحفظة من الخادم');if(faults.length)status('بعض الخدمات لم تُحدّث: '+faults.join('، '));return liveData;}
function screenHome(){const w=liveData.wallet||{},tx=w.transactions||[];const pack=liveData.packages?.packages||[],profiles=liveData.profiles?.profiles||[];return `<div class="jw-top"><div class="jw-head"><div><div class="jw-brand">محفظتي</div><div class="jw-sub">جوالي — متصل بخادم المحفظة</div></div><button class="jw-icon-btn" onclick="jawaliLiveRefresh()">↻</button></div><div class="jw-greet">مرحبًا، ${safe(liveUser?.name||'العميل')} 👋<small>${safe(liveUser?.phone)} · بيانات فعلية</small></div><div class="jw-balance"><div class="jw-balance-label">رصيد المحفظة <button class="jw-eye" onclick="toggleBalanceVisibility()">${balanceVisible?'إخفاء':'إظهار'}</button></div><div class="jw-amount" id="jw-amount">${balanceVisible?rial(w.balance):'••••••'}</div><div class="jw-balance-foot"><span class="jw-balance-pill">محفظتك المتصلة بالخادم</span></div></div></div><div class="jw-body"><div class="jw-quick"><button onclick="clientNavigate('topup')"><span class="jw-glyph">${jwIcon('plus')}</span>شحن الرصيد</button><button onclick="clientNavigate('transfer')"><span class="jw-glyph">${jwIcon('up')}</span>تحويل</button><button onclick="clientNavigate('cards')"><span class="jw-glyph">${jwIcon('layers')}</span>شراء كرت</button><button onclick="clientNavigate('water')"><span class="jw-glyph">${jwIcon('receipt')}</span>فواتير المياه</button></div><div class="jw-section-title">خدمات الشبكة</div><div class="lv-grid">${card('كروت الإنترنت','باقات للبيع',pack.length+' باقة','تصفح الباقات',"clientNavigate('cards')")}${card('دخول الشبكة','بروفايلات الهاتف',profiles.length+' بروفايل','اختر باقتك',"clientNavigate('internet')")}</div><div class="jw-section-title">آخر العمليات</div>${panel('كشف الحساب',tx.length?tx.slice(0,5).map(x=>line(x.description||'عملية',rial(x.amount))).join(''):notice('لا توجد عمليات مسجلة'))}<p class="lv-note" id="live-status"></p></div>`;}
function screenService(){const w=liveData.wallet||{};switch(clientTab){
case 'cards':{const packs=liveData.packages?.packages||[], cards=liveData.cards?.cards||[];return panel('متجر كروت الإنترنت',`<div class="lv-grid">${packs.map(p=>card(p.name,'المتوفر: '+fmt(p.availableCards)+' كرت',rial(p.price),p.availableCards>0?'شراء كرت':'نفد المخزون',`jawaliBuyCard('${safe(p.id)}')`)).join('')||notice('لا توجد باقات متاحة')}</div>`)+panel('كروتي المشتراة',cards.map(c=>line(c.package?.name||'كرت','الحالة: '+c.status+' · '+c.username)).join('')||notice('لا توجد كروت مشتراة'))}
case 'internet':{const profiles=liveData.profiles?.profiles||[];return panel('اختر بروفايل الهاتف',`<div class="lv-grid">${profiles.map(p=>card(p.name,`${fmt(p.speedMbps)} ميجابت/ث · ${fmt(p.durationMinutes)} دقيقة`,rial(p.price),'اختيار وتفعيل',`jawaliActivateProfile('${safe(p.id)}')`)).join('')||notice('لا توجد بروفايلات هاتف متاحة')}</div><p class="lv-note">يُربط البروفايل برقم هاتفك عبر الخادم وUser Manager عند موافقتك. الدخول إلى صفحة Hotspot يُستكمل على شبكة الراوتر.</p>`)}
case 'transfer':return '<div class="lv-finance-hero"><span>خدمات المحفظة</span><strong>تحويل الأموال</strong><small>تحويل بين حسابات مسجلة</small></div>'+panel('بيانات التحويل',`<label>رقم هاتف المستلم<input id="lv-to" type="tel" maxlength="9" inputmode="numeric" placeholder="77xxxxxxx"></label><label>المبلغ بالريال اليمني<input id="lv-amount" type="number" min="1" step="0.01"></label><label>وصف العملية<input id="lv-desc" maxlength="200" value="تحويل من جوالي محفظتي"></label>${button('مراجعة وتأكيد التحويل','jawaliTransfer()')}<p class="lv-note">التحويل الفعلي متوقف حتى اكتمال اختبار القيود المالية في الخادم.</p>`);
case 'topup':return '<div class="lv-finance-hero"><span>خدمات المحفظة</span><strong>شحن الرصيد</strong><small>طلب إضافة رصيد إلى حسابك</small></div>'+panel('تفاصيل طلب الشحن',`<label>المبلغ<input id="lv-request-amount" type="number" min="1" step="0.01"></label><label>ملاحظة<input id="lv-request-desc" value="طلب شحن محفظة"></label>${button('إرسال طلب الشحن','jawaliDepositRequest()')}<p class="lv-note">إرسال طلب الشحن الفعلي معلق لحين اختبار صلاحيات الخادم.</p>`);
case 'requests':{const a=liveData.requests?.requests||[];return panel('طلبات المحفظة',a.map(x=>line(x.description||x.type,rial(x.amount)+' · '+x.status)).join('')||notice('لا توجد طلبات'))}
case 'water':{const subs=liveData.water?.subscriptions||[];return panel('فواتير المياه',subs.map(sub=>`<h4>${safe(sub.project?.name||'مشروع مياه')}</h4>${(sub.invoices||[]).map(inv=>{const due=Math.max(0,Number(inv.totalAmount)-Number(inv.paidAmount));return `<article class="lv-card"><b>الفترة: ${safe(inv.billingPeriod)}</b><small>الحالة: ${safe(inv.status)}</small><strong>المتبقي: ${rial(due)}</strong>${due>0?notice('السداد المباشر يحتاج اعتماد قيد إيراد صاحب مشروع المياه في الخادم.'):''}</article>`}).join('')||notice('لا توجد فواتير')}`).join('')||notice('لا توجد اشتراكات مياه'))}
case 'history':return panel('كشف الحساب',(w.transactions||[]).map(x=>line(x.description||x.type,rial(x.amount))).join('')||notice('لا توجد عمليات'));
case 'account':return panel('بيانات حسابي',`${line('الاسم',liveUser?.name)}${line('رقم الهاتف',liveUser?.phone)}<h3>تغيير كلمة المرور</h3><label>الحالية<input id="lv-old" type="password"></label><label>الجديدة<input id="lv-new" type="password" placeholder="حرف إنجليزي وخمسة أرقام"></label><label>تأكيد الجديدة<input id="lv-confirm" type="password"></label>${button('حفظ كلمة المرور','jawaliChangePassword()')}<p class="lv-note">البصمة لا تُستعمل لتجاوز مصادقة الخادم. يلزم تخزين جلسة آمنة مستقل لتفعيل الدخول بها.</p>${button('تسجيل الخروج','clientLogout()')}`);
default:return panel('الخدمة',notice('هذا القسم لا يمتلك نقطة API مكتملة في النسخة الحالية. لا تُعرض عمليات وهمية أو تُنفَّذ إجراءات غير مرتبطة بالخادم.'));
}}
const priorLogin=clientLoginView,priorHome=jwHome,priorContent=clientServiceContent,priorLogout=clientLogout,priorNav=clientNavigate;
clientLoginView=function(){return `<section class="lv-login"><h2>جوالي محفظتي</h2>${notice('اتصال مباشر بحسابك على خادم المحفظة. يلزم عنوان HTTPS موثوق.')}
 <label>خادم المحفظة المتصل<input dir="ltr" id="lv-base" type="url" readonly value="${safe(saved)}"></label>${button('فحص الخادم','jawaliCheck()')}
 <label>رقم الهاتف<input id="lv-phone" type="tel" inputmode="numeric" maxlength="9" autocomplete="username"></label><label>كلمة المرور<input id="lv-password" type="password" autocomplete="current-password"></label>${button('تسجيل الدخول','jawaliLogin()')}<p id="live-status" class="lv-note" aria-live="polite"></p></section>`};
window.jawaliCheck=async()=>{try{apiBase=SERVER_URL;const x=await call('/api/health');if(x.ok!==true||x.database!=='connected')throw new Error('قاعدة البيانات غير متصلة');status('تم الاتصال بخادم المحفظة وقاعدة البيانات');}catch(e){status(errorText(e))}};
window.jawaliLogin=async()=>{if(busy)return;busy=true;try{
 const phone=document.getElementById('lv-phone').value.trim(),password=document.getElementById('lv-password').value;if(!/^(71|73|77|78)[0-9]{7}$/.test(phone))throw new Error('رقم الهاتف غير صحيح');
 apiBase=SERVER_URL;const deviceToken=window.JawaliNative?.deviceToken?.();if(!deviceToken||deviceToken.length<16)throw new Error('تعذّر التحقق من هوية الجهاز');
 status('جارٍ تسجيل الدخول…');const r=await call('/api/auth/client-login','POST',{phone,password,deviceToken});if(!r.token||!r.user)throw new Error('جلسة الدخول غير مكتملة');token=r.token;liveUser=r.user;
 await refresh();try{localStorage.setItem('jawali_api_base',apiBase)}catch(e){}activeClient=phone;clientSession=phone;clientTab='home';render();
 }catch(e){token=null;liveUser=null;clientSession=null;status(errorText(e))}finally{busy=false}};
async function write(path,body,confirmation){if(path!=='/api/client/account/password')return toast('العمليات المالية مؤجلة لحين إتمام اختبار تسجيل الدخول والأرصدة على الهاتف');if(busy)return; if(!confirm(confirmation+'\n\nسيتم تنفيذ العملية على المحفظة الحقيقية.'))return;busy=true;try{const r=await call(path,'POST',body);toast(r.message||'تم التنفيذ بنجاح');await refresh();render();}catch(e){toast(errorText(e)+' — تحقّق من كشف الحساب قبل إعادة المحاولة');}finally{busy=false}}
window.jawaliBuyCard=id=>{const p=(liveData.packages?.packages||[]).find(x=>x.id===id);if(!p||!(p.availableCards>0))return toast('الكرت غير متوفر');write('/api/client/cards/purchase',{packageId:id},`شراء كرت ${p.name} بقيمة ${rial(p.price)}؟`)};
window.jawaliActivateProfile=id=>{const p=(liveData.profiles?.profiles||[]).find(x=>x.id===id);if(!p)return;const d=window.JawaliNative?.deviceToken?.();if(!d)return toast('تعذّر التعرف على الجهاز');write('/api/client/wifi-phone-login',{phoneProfileId:id,deviceToken:d},`شراء وتفعيل بروفايل ${p.name} برقم هاتفك بقيمة ${rial(p.price)}؟`)};
window.jawaliTransfer=()=>{const phone=document.getElementById('lv-to').value.trim(),amount=Number(document.getElementById('lv-amount').value),description=document.getElementById('lv-desc').value.trim();if(!/^(71|73|77|78)[0-9]{7}$/.test(phone)||!Number.isFinite(amount)||amount<=0||description.length<2)return toast('تحقق من رقم المستلم والمبلغ والوصف');write('/api/client/transfer',{phone,amount,description},`تحويل ${rial(amount)} إلى ${phone}؟`)};
window.jawaliDepositRequest=()=>{const amount=Number(document.getElementById('lv-request-amount').value),description=document.getElementById('lv-request-desc').value.trim();if(!Number.isFinite(amount)||amount<=0||description.length<2)return toast('أدخل مبلغًا ووصفًا صحيحين');write('/api/client/requests',{type:'DEPOSIT',amount,description},`إرسال طلب شحن بقيمة ${rial(amount)}؟`)};
window.jawaliChangePassword=()=>{const currentPassword=document.getElementById('lv-old').value,newPassword=document.getElementById('lv-new').value,confirmation=document.getElementById('lv-confirm').value;if(!/^[A-Za-z][0-9]{5}$/.test(newPassword)||newPassword!==confirmation)return toast('كلمة المرور الجديدة يجب أن تكون حرفًا إنجليزيًا وخمسة أرقام متطابقة');write('/api/client/account/password',{currentPassword,newPassword},'تغيير كلمة المرور الآن؟')};
window.jawaliLiveRefresh=async()=>{try{await refresh();render();toast('تم تحديث بيانات الخادم')}catch(e){toast(errorText(e))}};
clientNavigate=function(t){priorNav(t);if(liveUser)window.jawaliLiveRefresh()};
jwHome=function(){return liveUser?screenHome():priorHome()};clientServiceContent=function(){return liveUser?screenService():priorContent()};
clientLogout=function(){if(!liveUser)return priorLogout();token=null;liveUser=null;liveData={};activeClient='';clientSession=null;clientTab='home';go('client')};
window.JawaliLiveBalance=()=>rial(liveData.wallet?.balance);
// The connected client app must never expose simulated administration pages.
const legacyGo=go;
go=function(target){if(target!=='client'){toast('هذه الواجهة التجريبية ليست ضمن التطبيق المتصل بالخادم');return;}legacyGo(target);};
let liveAuthMode='login';
window.jawaliShowAuth=function(mode){liveAuthMode=mode==='register'?'register':'login';render();window.scrollTo(0,0)};
clientLoginView=function(){
 const reg=liveAuthMode==='register';
 const fields=reg?'<label>الاسم الرباعي باللغة العربية<input id="lv-reg-name" maxlength="120" autocomplete="name" placeholder="الاسم الأول والأب والجد واللقب"></label><label>رقم الهاتف<input id="lv-reg-phone" type="tel" inputmode="numeric" maxlength="9" placeholder="77xxxxxxx"></label><label>كلمة المرور<input id="lv-reg-pass" type="password" autocomplete="new-password" placeholder="حرف إنجليزي وخمسة أرقام"></label><label>تأكيد كلمة المرور<input id="lv-reg-confirm" type="password" autocomplete="new-password"></label><label>البريد الإلكتروني (اختياري)<input id="lv-reg-email" type="email" autocomplete="email"></label>':'<label>رقم الهاتف<input id="lv-phone" type="tel" inputmode="numeric" maxlength="9" autocomplete="username" placeholder="77xxxxxxx"></label><label>كلمة المرور<input id="lv-password" type="password" autocomplete="current-password"></label>';
 return '<section class="lv-auth-shell" dir="rtl"><div class="lv-auth-hero"><div class="lv-auth-logo">◈</div><div>جوالي محفظتي</div><h1>'+(reg?'إنشاء حساب جديد':'مرحبًا بعودتك')+'</h1><p>'+(reg?'أنشئ حسابك للوصول إلى خدمات المحفظة':'ادخل بحسابك المرتبط برقم الهاتف')+'</p></div><div class="lv-login lv-auth-form">'+fields+'<button class="lv-action" onclick="'+(reg?'jawaliRegister()':'jawaliLogin()')+'">'+(reg?'إنشاء الحساب':'تسجيل الدخول')+'</button><div class="lv-auth-switch">'+(reg?'لديك حساب؟':'ليس لديك حساب؟')+' <button type="button" onclick="jawaliShowAuth(\''+(reg?'login':'register')+'\')">'+(reg?'تسجيل الدخول':'إنشاء حساب جديد')+'</button></div><p id="live-status" role="alert" aria-live="polite" class="lv-note"></p><p class="lv-auth-safe">اتصال HTTPS بخادم المحفظة المعتمد. إدارة الخادم مخصصة للمسؤول فقط.</p></div></section>';
};
window.jawaliRegister=async function(){
 if(busy)return;
 const val=id=>document.getElementById(id)?.value.trim()||'';
 const name=val('lv-reg-name'),phone=val('lv-reg-phone'),password=document.getElementById('lv-reg-pass')?.value||'',confirmation=document.getElementById('lv-reg-confirm')?.value||'',email=val('lv-reg-email');
 if(!/^[\u0621-\u064A]+(?:\s+[\u0621-\u064A]+){3}$/.test(name))return status('أدخل اسمًا رباعيًا باللغة العربية فقط');
 if(!/^(71|73|77|78)[0-9]{7}$/.test(phone))return status('رقم الهاتف 9 أرقام إنجليزية ويبدأ بـ 71 أو 73 أو 77 أو 78');
 if(!/^[A-Za-z][0-9]{5}$/.test(password))return status('كلمة المرور: حرف إنجليزي ثم خمسة أرقام');
 if(password!==confirmation)return status('كلمتا المرور غير متطابقتين');
 if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return status('صيغة البريد الإلكتروني غير صحيحة');
 const deviceToken=window.JawaliNative?.deviceToken?.();if(!deviceToken||deviceToken.length<16)return status('تعذر التحقق من هذا الجهاز');
 busy=true;
 try{status('جارٍ إرسال طلب إنشاء الحساب…');const r=await call('/api/auth/client-register','POST',{name,phone,password,email,deviceToken});if(r.ok!==true&&r.created!==true&&!r.user)throw new Error('الخادم لم يؤكد إنشاء الحساب');liveAuthMode='login';render();status('تم إنشاء الحساب في الخادم؛ سجّل الدخول الآن');}
 catch(e){status(e.status===404||e.status===405?'إنشاء الحساب غير متاح في الخادم حتى يفعّله المسؤول.':errorText(e));}
 finally{busy=false;}
};

// Never launch a demo dashboard when opening the connected Android build.
setTimeout(()=>{try{go('client')}catch(e){}},0);
})();
